<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class badge_model extends CI_Model {

	function __construct(){
  	  parent::__construct();
    }

    //TODO
    //다른 모델을 로드하도록 한다.
    function model_load_model($model_name)
   	{
	      $CI =& get_instance();
	      $CI->load->model($model_name);
	      $temp = split("/",$model_name);
	      return $CI->$temp[1];
   	}

	//TODO
	//get badge list about badgeID and getprocess, e.g) cj1, a3
	//배지의 리스트를 받아온다.
	function get_badgelist()
	{
		return $this->openapi_db->query("SELECT id, name, getprocess, description, status, scarcity FROM member_badges");
	}

	//TODO
	//새로운 배지를 추가한다.
	function insert_badge($name,$description,$getprocess)
	{
		$Query = "INSERT INTO member_badges(name, description, getprocess)
              			  VALUES(?,?,?)";

	       	$array = array($name,$description,$getprocess);
	    	$this->openapi_db->query($Query,$array);

  	}
	
	//TODO
	//insert into member_badge_grant about number of issued api key
	//배지를 사용자에게 부여한다.
	function grant_badge()
	{

		$badgelist = $this->get_badgelist()->result();

		foreach($badgelist as $b)
		{	
			
			switch ($b->name) {
					
				//TODO
				//DNA 카페에 가압된 사람에게 수여한다. 배지코드 - cj1
				case 'cj1':

					$this->grant_badge_based_cafe();
					break;

				//TODO
				//API를 기준 이상 발급 받은 사람에게 수여한다 .배지코드 - a1, a3, a5
				//한번만 부르면, a1,a3,a5 발급 가능 
				case 'a1' :
					$this->grant_badge_based_api();
					break;			


				//TODO
				//질문 게시판에 글을 50번 이상 게시한 사람에게 수여한다. 배지코드 - qna50
				case (preg_match('/^qna/', $b->getprocess) ? true : false) :
					$this->grant_badge_based_cafe_boardType("KErw",50,$b->id);
					break;


				//TODO
				//게시판을 통틀어 총 글을 기준 이상 작성한 사람에게 수여한다. 배지코드 - bw5, bw30
				case (preg_match('/^bw/', $b->getprocess) ? true : false) :
					$this->grant_badge_based_cafe_boardType(0,str_replace('bw','',$b->getprocess),$b->id);
					break;

				//TODO
				//카페를 기준 이상 방문한 사람에게 수여한다. (한줄 메모장에 남긴 글의 갯수로 확인) 배지코드 - vc3, vc30, vc50
				case (preg_match('/^vc/', $b->getprocess) ? true : false) :
					$this->grant_badge_based_cafe_boardType("_memo",str_replace('vc','',$b->getprocess),$b->id);
					break;
				
				//TODO
				//이벤트에 참가하여서 수상 경렬 횟수로 배지를 부여한다. 배지코드 - ew1
				case (preg_match('/^ew/', $b->getprocess) ? true : false) :
					$this->grant_badge_based_event("prize");
					break;

				//TODO
				//이벤트에 참가한 횟수로 배지를 부여한다. 배지코드 - ep3, ep5
				case 'ep3':
					$this->grant_badge_based_event("none");

//					break;

				default:
					# code...
					break;
			}
			

		}
	}


function grant_badge_based_api() //api 기준 벳지 부여 함수 
{
	
	$getbadgedate = date("Y-m-d H:i:s");
	
	$temp= $this->openapi_db->query("SELECT id from member_members as k natural join (SELECT distinct userid, count(*)  as count  FROM api_key  WHERE issuedate BETWEEN DATE_ADD(CURDATE(), INTERVAL -1 day) AND CURDATE() group by userid) as t  ")->result();
	foreach($temp as $b)
	{
		
		$userid=$this->id_to_userid($b->id);
	
		$count=$this->count_frequency_helper($userid, "api_key");	

		
		if($count>=1)
			if($this->has_granted_helper($b->id,2)==0)
				$this->badge_grant_helper(2,$b->id);
			
		if($count>=3)
			if($this->has_granted_helper($b->id,3)==0)
				$this->badge_grant_helper(3,$b->id);
		if($count>=5)
			if($this->has_granted_helper($b->id,4)==0)
				$this->badge_grant_helper(4,$b->id);
		



	}	
}

function grant_badge_based_cafe() //카페 가입시 벳지 부여 함수  
{
	$getbadgedate = date("Y-m-d H:i:s");
	$temp = $this->openapi_db->query("SELECT distinct *  FROM member_members WHERE cafejoin=1 and createdate BETWEEN DATE_ADD(CURDATE(), INTERVAL -1 day) AND CURDATE() ")->result();
	foreach($temp as $b)
	{	

		$id=$b->id;
	
		if($this->has_granted_helper($id,1)==0)
		{	$this->badge_grant_helper(1,$id);}
		
	}	

}
function grant_badge_based_cafe_boardType($boardid,$Number,$badgeNumber) //카페의 게시판 기반 벳지 부여 함수 
{
	$getbadgedate = date("Y-m-d H:i:s");

	if($boardid==0)
	{
		$temp=$this->openapi_db->query("SELECT member_id,writedate FROM openapi.member_board_activity where  type='board' and writedate BETWEEN DATE_ADD(CURDATE(), INTERVAL -1 day) AND CURDATE() group by member_id ")->result();
	}
	else
	{
		$temp=$this->openapi_db->query("SELECT member_id,writedate FROM openapi.member_board_activity where  boardid="."'".$boardid."'"." and writedate BETWEEN DATE_ADD(CURDATE(), INTERVAL -1 day) AND CURDATE() group by userid ")->result();
	}

	foreach($temp as $b)
	{
		
		$userid=$this->id_to_userid($b->id);
		$count=$this->count_frequency_helper($userid, "member_board_activity");

		if($this->has_granted_helper($b->member_id,$badgeNumber)==0)
		{
	
				if($count>=$Number)
					$this->badge_grant_helper($badgeNumber,$b->member_id);


		}

	}


}




function grant_badge_based_event($type) //이벤트 기반 함수
{
	$getbadgedate = date("Y-m-d H:i:s");

	if($type=="prize")
		$temp=$this->openapi_db->query("SELECT member_id from member_event_join where prize IS NOT NULL and joindate BETWEEN DATE_ADD(CURDATE(), INTERVAL -1 day) AND CURDATE() group by member_id  ")->result();

	else
		$temp=$this->openapi_db->query("SELECT member_id from member_event_join where joindate BETWEEN DATE_ADD(CURDATE(), INTERVAL -1 day) AND CURDATE() group by member_id  ")->result();
	
	foreach($temp as $b)
	{
		if($type=="prize")	
		{		
			if(has_granted_helper($b->member_id,11)==0)
			{	
				$this->badge_grant_helper(11,$b->member_id);
		
			}
		} 

		else
		{
			$userid=$this->id_to_userid($b->id);		
			$count=$this->count_frequency_helper($userid, "member_event_join");
			
			
			if(has_granted_helper($b->id,12)==false)
			{
					if($count>=3)
						$this->badge_grant_helper(12,$b->userid);
			}
			if(has_granted_helper($b->id,13)==false)
			{
					if($count>=5)
						$this->badge_grant_helper(13,$b->userid);
		
			}




		}
	}


}



function count_frequency_helper($userid,$table) //특정 테이블의 유저가 활동한 빈번도 확인 헬퍼 
{
	$row= $this->openapi_db->query("SELECT count(*) as count, userid from ".$table." where userid="."'".$userid."'"." group by userid order by count desc")->row(0);
	return $row->count;
}

function has_granted_helper($member_id,$badge) //지금 부여하려는 벳지가 유저가 보유하고 있는지 확인한다
{

	$query=$this->openapi_db->query("SELECT member_id from member_badge_grant where member_id="."'".$member_id."'"." and badge_id="."'".$badge."'"." ");
	return $query->num_rows();
	
}


function badge_grant_helper($badgeNumber,$userid) //뱃지 부여 통합 헬퍼 함수 
{
	$getbadgedate = date("Y-m-d H:i:s");
	$this->openapi_db->query("INSERT INTO member_badge_grant(badge_id,grantdate,member_id) VALUES("."'".$badgeNumber."'".","."'".$getbadgedate."'".","."'".$userid."'".")");
}

function userid_to_id($userid)
{

		$row=$this->openapi_db->query("SELECT * from member_members where userid="."'".$userid."'"."")->row(0);
	
		return $row->id;

}


function id_to_userid($id)
{
	$row= $this->openapi_db->query("SELECT userid from member_members where id="."'".$id."'"."")->row(0);
	return $row->userid;
}




  
  //TODO
  //회원 중 배지를 받은 사람의 리스트를 가져온다.
  function show_member_badge(){
      return $this->openapi_db->query("SELECT * 
                                       FROM member_members JOIN member_badge_grant AS m ON (member_members.id = m.member_id) JOIN member_badges ON (m.badge_id = member_badges.id)
                                       ORDER BY m.member_id DESC"
      );
  }

  //TODO
  //배지의 희소성을 계산한다. (배지를 수여받은 사람 수 / 전체 사람 수)*100 로 계산한다.
  function calcul_badge_scarcity()
  {
  	$totalMemberObj = $this->model_load_model("dnaver/member_model")->total_member()->result();
  	$totalMember = $totalMemberObj[0]->cnt;

  	$badgelist = $this->get_badgelist()->result();

  	foreach ($badgelist as $b)
  	{
  		$Query = "UPDATE member_badges 
  	 		  SET scarcity = (SELECT round( count(badge_id)/? * 100 ,2) FROM member_badge_grant WHERE badge_id = ?),
			  used = (SELECT if(count(badge_id)=0,0,1) FROM member_badge_grant WHERE badge_id = ?)
			  WHERE id = ?";

		$Array = array($totalMember,$b->id,$b->id,$b->id);
  		$this->openapi_db->query($Query,$Array);
  	}
  }
}

/* End of file badge_model.php */
/* Location: ./system/application/models/dnaver/badge_model.php */