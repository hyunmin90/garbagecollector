<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Daum Developers</title>
    </head>    
        <!-- BSA AdPacks code. Please ignore and remove.--> 
        <script src="<?php echo asset_url();?>js/jquery-1.8.2.min.js"></script>
        <script src="<?php echo asset_url();?>js/libs/jquery-1.9.1.js"></script>
        <script src="<?php echo asset_url();?>js/libs/handlebars-1.0.0.js"></script>
        <script src="<?php echo asset_url();?>js/libs/ember-1.0.0-rc.8.js"></script>
        <script src="http://cdnjs.cloudflare.com/ajax/libs/showdown/0.3.1/showdown.min.js"></script>
        <script src="http://cdnjs.cloudflare.com/ajax/libs/moment.js/2.1.0/moment.min.js"></script>

        <script src="<?php echo asset_url();?>js/bootstrap.js"></script>

        <div style="width:100%;height:83px;background-image:url('/assets_dev/header.png'); margin-bottom: 10px;"></div>
