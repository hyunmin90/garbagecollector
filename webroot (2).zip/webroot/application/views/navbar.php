<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

<div class="navbar navbar-default navbar-fixed-top" role="navigation">
<div class="container-fluid">

          <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav ">

              <li ><a href="<?php echo base_url();?>whycle/main/">Create VM</a></li>
              <li><a href="<?php echo base_url();?>whycle/main/listvm">List VM</a></li>
              <li><a href="<?php echo base_url();?>whycle/main/muttforum">Board</a></li>
      	
      	

            </ul>
          
          </div><!--/.nav-collapse -->
        </div>
    </div>