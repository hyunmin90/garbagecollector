
 $.ajax({
                                url: "/index.php/whycle/api/vmlist",
                                dataType: "json",
                                async: true,
                                success: function(json) {
                                  
                                   count = json.listvmresponse.count; 
                                   for(i=0;i<count;i++){        
                                    $("#vm").append("<div class =well id=vmname"+i+" onclick=toggling('"+i+"')>"+"<a>"+json.listvmresponse.virtualmachine[i].name+
                                        "</a></div><div id='vmdetail"+i+"' class=details >"+"<ul><li>"+json.listvmresponse.virtualmachine[i].ipaddress+"</li>"+
                                        "<li>"+json.listvmresponse.virtualmachine[i].templatename+"</li>"+"<li id=status"+i+">"+
                                        json.listvmresponse.virtualmachine[i].state+"</li>"+"</ul><button type=button class='btn btn-default' id=stopvm onclick='stopvm("+'"'+json.listvmresponse.virtualmachine[i].id+'"'+","+i+")'>stopvm</button><button type=button class='btn btn-default' id=startvm onclick='startvm("+'"'+json.listvmresponse.virtualmachine[i].id+'"'+","+i+")'>startvm</button><button type=button class='btn btn-default' id=deletevm onclick='deletevm("+'"'+json.listvmresponse.virtualmachine[i].id+'"'+","+i+")'>deletevm</button>");                     
                                      


                                    }

                             
                                }

                            
                            });
               
               function toggling(arg){
                                              $("#vmdetail"+arg).toggle('slow'); 
                                        };

function stopvm(arg,num){
    alert(num);
    var requireddata={
        vmid: arg,}; 
$.ajax({
    url:"/index.php/whycle/api/vmstop",
    data:requireddata,
    dataType:"json",
    async:true,
    success:function(json){
        alert("stopping vm please wait");
        $("#status"+num).replaceWith("<li id=status>stop");
    },
    error:function(json){
        alert("cant stopped vm. error occured");
    }

});

};

function startvm(arg,num){

    var requireddata={
        vmid: arg,}; 
$.ajax({
    url:"/index.php/whycle/api/vmstart",
    data:requireddata,
    dataType:"json",
    async:true,
    success:function(json){
        alert("starting vm please wait");
        $("#status"+num).replaceWith("<li id=status>start");
    },
    error:function(json){
        alert("cant start vm. error occured");
    }

});





};

function deletevm(arg,num)
{
    alert(arg);
 var requireddata=
 {
vmid:arg,
 };
$.ajax({
url:"/index.php/whycle/api/vmdestroy",
data:requireddata,
dataType:"json",
async:true,
success:function(json){
    alert("deleting vm. Please wait");
},
error:function(json){
    alert("failed to delete vm");
}

});



};