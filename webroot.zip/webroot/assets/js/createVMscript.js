
var spec =[];

function  createvm()
{	
	if (spec[0]==null||spec[1]==null||spec[2]==null)
		alert("You have not selected all spec");
	else
	spec[3]=$("#nametxt").val();
	spec[4]="6967f186-0369-11e4-a62a-60a44c60711e";
	alert(spec[3]);
	var requireddata={
	ram:spec[0],
	hdd:spec[1],
	cpu:spec[2],
	name:spec[3],	
	templateid:spec[4],
	};
	  $.ajax({
                                url: "/index.php/whycle/api/vmdeploy",
                                data:requireddata,
                                dataType: "json",
                                async: true,
                                success: function(json) {
                                    alert("created vm. please wait");
                                },
                                  error: function(json){
                                  alert("sent failed");
                                }
                            });




	

} 
function addram(size)
{	
	spec[0]=size;

}
function addhdd(hdd){
	spec[1]=hdd;
}
function addcpu(cpu){
	spec[2]=cpu;

}
