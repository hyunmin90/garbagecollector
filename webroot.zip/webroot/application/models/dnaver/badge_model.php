<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class badge_model extends CI_Model {

	function __construct(){
  	  parent::__construct();
    }

//TODO
//insert into member_badgegrant about number of issued api key
	function grant_api_badge()
	{
	   $this->openapi_db->query("INSERT INTO member_badgegrant(badge,getbadgedate,userid)
									 SELECT M.badge, T.getbadgedate, T.userid
									 FROM member_badge AS M
						             JOIN (SELECT
								                  userid,
								                  COUNT(userid) AS count,        
								                  CONCAT('API',COUNT(userid)) AS getprocess,
								                  (SELECT issuedate FROM api_key AS B WHERE B.userid = api_key.userid ORDER BY issuedate DESC LIMIT 1) AS getbadgedate
							               FROM api_key
							               GROUP BY userid) AS T ON T.getprocess = M.getprocess
						             WHERE T.userid IN (SELECT userid FROM member_user)
						             AND (T.count=1 OR T.count=3 OR T.count=5 OR T.count>5)
						             AND T.userid NOT IN(SELECT userid FROM member_badgegrant WHERE T.getbadgedate=getbadgedate AND M.badge=badge)
						         ");
	}

	function grant_prize_badge()
	{
		 $this->openapi_db->query(
	}
}
//    HAVING COUNT(userid)=1 OR COUNT(userid)=3 OR COUNT(userid)=5

/* End of file badge_model.php */
/* Location: ./system/application/models/dnaver/badge_model.php */