<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class cafe_model extends CI_Model {

	function insert()
	{
		$this->db1->query();
	}
}

/* End of file cafe_model.php */
/* Location: ./system/application/models/dnaver/cafe_model.php */