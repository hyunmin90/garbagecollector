<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class event_model extends CI_Model {

	function insert()
	{
		$this->db1->query();
	}
}


/* End of file event_model.php */
/* Location: ./system/application/models/dnaver/event_model.php */