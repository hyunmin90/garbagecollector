<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class member_model extends CI_Model {

  function __construct(){
    parent::__construct();
  }

  //TODO
  //insert user issued api key into member_user Table
  function insert_openapi() {

     $this->openapi_db->query("INSERT INTO member_user(userid,create_day,joinpath)
              SELECT
                  DISTINCT userid,
                  (SELECT issuedate FROM api_key AS B WHERE B.userid = api_key.userid ORDER BY issuedate LIMIT 1) AS create_date ,
                  'openapi'
              FROM api_key
              WHERE
                  issuedate > (SELECT create_day FROM member_user WHERE joinpath = 'openapi' ORDER BY create_day DESC LIMIT 1)
                  AND
                  userid NOT IN (SELECT userid FROM member_user )");
  }
  //TODO
  //insert user participating event into member_user Table
  function insert_event() {

     $this->openapi_db->query("INSERT INTO member_user(userid,create_day,joinpath)
              SELECT
                  DISTINCT userid,
                  (SELECT registerdate FROM member_event_join AS B WHERE B.userid = member_event_join.userid ORDER BY registerdate LIMIT 1) AS create_date ,
                  'event'
              FROM member_event_join
              WHERE
                  registerdate > (SELECT create_day FROM member_user WHERE joinpath = 'event' ORDER BY create_day DESC LIMIT 1)
                  AND
                  userid NOT IN (SELECT userid FROM member_user )");
  }
  //TODO
  //insert user writing post into member_user Table
  //not have cafe API
  function insert_cafe() {

     $this->openapi_db->query("INSERT INTO member_user(userid,create_day,joinpath)
              SELECT
                  DISTINCT userid,
                  (SELECT writedate FROM member_cafeactivity AS B WHERE B.userid = member_cafeactivity.userid ORDER BY writedate LIMIT 1) AS create_date ,
                  'cafe'
              FROM member_cafeactivity 
              WHERE
                  writedate > (SELECT create_day FROM member_user WHERE joinpath = 'cafe' ORDER BY create_day DESC LIMIT 1)
                  AND
                  userid NOT IN (SELECT userid FROM member_user )");
  }
}
/* End of file member_model.php */
/* Location: ./system/application/models/dnaver/member_model.php */