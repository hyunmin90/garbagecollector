<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>CSS3 Animated Navigation Menu | Tutorialzine Demo</title>

        <!-- Our CSS stylesheet file -->
        <link rel="stylesheet" href="<?php echo asset_url();?>css/styles.css" />

		<!-- Font Awesome Stylesheet -->
		<link rel="stylesheet" href="<?php echo asset_url();?>font-awesome/css/font-awesome.css" />

		<!-- Including Open Sans Condensed from Google Fonts -->
		<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,700,300italic" />
		<link href="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.no-icons.min.css" rel="stylesheet">
        <!--[if lt IE 9]>
          <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
    </head>
    <body>  
  <script type="text/x-handlebars">


    	<nav id="colorNav">
			<ul>
				<li class="green">
					{{#link-to 'php' class="icon-php"}}{{/link-to}}
				
				</li> 
				<li class="red">
					{{#link-to 'Nodejs' class="icon-nodejs"}}{{/link-to}}
					
				</li>
				<li class="blue">
					{{#link-to 'jsp'  class="icon-jsp"}}{{/link-to}}
					
				</li>
				<li class="yellow">
					{{#link-to 'Django' class="icon-pythondjango"}}{{/link-to}}
					
				</li>
				<li class="purple">
					{{#link-to 'Ruby' class="icon-ruby"}}{{/link-to}}
					
				</li>
			</ul>
		</nav>



		 {{outlet}}
    			
</script>


  <script type="text/x-handlebars" id="php">
      
<div class="navbar">
      <div class="navbar-inner">
  		<h3> PHP server setup

                  	<div class="input-group input-group-lg" id="vmname">
 
  			<input type="text" class="form-control" placeholder="Virtual Machine name" id="nametxt">
			
	       	</div>
		<div id="specdetail" class="cpu">	
	       	<input type="button" class="btn btn-inverse btn-large " value="500mhz" onclick="addcpu('500')"/>
	       	<input type="button" class="btn btn-inverse btn-large" value="1Ghz" onclick="addcpu('1')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="2Ghz" onclick="addcpu('2')"/>
		</div>
		
		<div id="specdetail" class="ram">	
	       	<input type="button" class="btn btn-inverse btn-large " value="512mb" onclick="addram('512')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="1GB" onclick="addram('1024')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="2GB" onclick="addram('2048')"/>
		</div>
		
		<div id="specdetail" class="hdd">	
	       	<input type="button" class="btn btn-inverse btn-large " value="5GB"onclick="addhdd('5')" />
	       	<input type="button" class="btn btn-inverse btn-large " value="10GB" onclick="addhdd('10')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="20GB" onclick="addhdd('20')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="50GB" onclick="addhdd('50')"/>
		</div>		

		

      </div>
      </div>
      	<div id="submit">
      		<input type="submit" class="btn btn-success btn-large active" value="CREATE" onclick="createvm()"/>
      	</div>
  </script>


  <script type="text/x-handlebars" id="Nodejs">
      
<div class="navbar">
      <div class="navbar-inner">
  		<h3> Nodejs server setup

                  	<div class="input-group input-group-lg" id="vmname">
 
  			<input type="text" class="form-control" placeholder="Virtual Machine name" id="nametxt">
			
	              	</div>
		<div id="specdetail" class="cpu">	
	       	<input type="button" class="btn btn-inverse btn-large " value="500mhz" onclick="addcpu('500')"/>
	       	<input type="button" class="btn btn-inverse btn-large" value="1Ghz" onclick="addcpu('1')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="2Ghz" onclick="addcpu('2')"/>
		</div>
		
		<div id="specdetail" class="ram">	
	       	<input type="button" class="btn btn-inverse btn-large " value="512mb" onclick="addram('512')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="1GB" onclick="addram('1024')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="2GB" onclick="addram('2048')"/>
		</div>
		
		<div id="specdetail" class="hdd">	
	       	<input type="button" class="btn btn-inverse btn-large " value="5GB"onclick="addhdd('5')" />
	       	<input type="button" class="btn btn-inverse btn-large " value="10GB" onclick="addhdd('10')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="20GB" onclick="addhdd('20')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="50GB" onclick="addhdd('50')"/>
		</div>		


		

      </div>
      </div>
      	<div id="submit">
      		<input type="submit" class="btn btn-success btn-large active" value="CREATE" onclick="createvm()"/>
      	</div>
  </script>



  <script type="text/x-handlebars" id="jsp">
      
<div class="navbar">
      <div class="navbar-inner">
  	<h3> JSP server setup

                  	<div class="input-group input-group-lg" id="vmname">
 
  			<input type="text" class="form-control" placeholder="Virtual Machine name" id="nametxt">
			
	       	       	</div>
		<div id="specdetail" class="cpu">	
	       	<input type="button" class="btn btn-inverse btn-large " value="500mhz" onclick="addcpu('500')"/>
	       	<input type="button" class="btn btn-inverse btn-large" value="1Ghz" onclick="addcpu('1')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="2Ghz" onclick="addcpu('2')"/>
		</div>
		
		<div id="specdetail" class="ram">	
	       	<input type="button" class="btn btn-inverse btn-large " value="512mb" onclick="addram('512')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="1GB" onclick="addram('1024')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="2GB" onclick="addram('2048')"/>
		</div>
		
		<div id="specdetail" class="hdd">	
	       	<input type="button" class="btn btn-inverse btn-large " value="5GB"onclick="addhdd('5')" />
	       	<input type="button" class="btn btn-inverse btn-large " value="10GB" onclick="addhdd('10')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="20GB" onclick="addhdd('20')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="50GB" onclick="addhdd('50')"/>
		</div>		
	

		

      </div>
      </div>
      	<div id="submit">
      		<input type="submit" class="btn btn-success btn-large active" value="CREATE" onclick="createvm()"/>
      	</div>
  </script>



  <script type="text/x-handlebars" id="Django">
      
<div class="navbar">
      <div class="navbar-inner">
  		<h3> Django server setup

                  	<div class="input-group input-group-lg" id="vmname">
 
  			<input type="text" class="form-control" placeholder="Virtual Machine name" id="nametxt">
			
	       	       	</div>
		<div id="specdetail" class="cpu">	
	       	<input type="button" class="btn btn-inverse btn-large " value="500mhz" onclick="addcpu('500')"/>
	       	<input type="button" class="btn btn-inverse btn-large" value="1Ghz" onclick="addcpu('1')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="2Ghz" onclick="addcpu('2')"/>
		</div>
		
		<div id="specdetail" class="ram">	
	       	<input type="button" class="btn btn-inverse btn-large " value="512mb" onclick="addram('512')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="1GB" onclick="addram('1024')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="2GB" onclick="addram('2048')"/>
		</div>
		
		<div id="specdetail" class="hdd">	
	       	<input type="button" class="btn btn-inverse btn-large " value="5GB"onclick="addhdd('5')" />
	       	<input type="button" class="btn btn-inverse btn-large " value="10GB" onclick="addhdd('10')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="20GB" onclick="addhdd('20')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="50GB" onclick="addhdd('50')"/>
		</div>		


		

      </div>
      </div>
   <div id="submit">
      		<input type="submit" class="btn btn-success btn-large active" value="CREATE" onclick="createvm()"/>
      	</div>
  </script>



  <script type="text/x-handlebars" id="Ruby">
      
<div class="navbar">
      <div class="navbar-inner">
  	<h3> Ruby server setup

                  	<div class="input-group input-group-lg" id="vmname">
 
  			<input type="text" class="form-control" placeholder="Virtual Machine name" id="nametxt">
			
	        	</div>
		<div id="specdetail" class="cpu">	
	       	<input type="button" class="btn btn-inverse btn-large " value="500mhz" onclick="addcpu('500')"/>
	       	<input type="button" class="btn btn-inverse btn-large" value="1Ghz" onclick="addcpu('1')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="2Ghz" onclick="addcpu('2')"/>
		</div>
		
		<div id="specdetail" class="ram">	
	       	<input type="button" class="btn btn-inverse btn-large " value="512mb" onclick="addram('512')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="1GB" onclick="addram('1024')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="2GB" onclick="addram('2048')"/>
		</div>
		
		<div id="specdetail" class="hdd">	
	       	<input type="button" class="btn btn-inverse btn-large " value="5GB"onclick="addhdd('5')" />
	       	<input type="button" class="btn btn-inverse btn-large " value="10GB" onclick="addhdd('10')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="20GB" onclick="addhdd('20')"/>
	       	<input type="button" class="btn btn-inverse btn-large " value="50GB" onclick="addhdd('50')"/>
		</div>		

		

      </div>
      </div>
      	<div id="submit">
      		<input type="submit" class="btn btn-success btn-large active" value="CREATE" onclick="createvm()"/>
      	</div>
  </script>




        <!-- BSA AdPacks code. Please ignore and remove.--> 
		<script src="http://code.jquery.com/jquery-1.8.2.min.js"></script>
		<script src="<?php echo asset_url();?>js/libs/jquery-1.9.1.js"></script>
  		<script src="<?php echo asset_url();?>js/libs/handlebars-1.0.0.js"></script>
  		<script src="<?php echo asset_url();?>js/libs/ember-1.0.0-rc.8.js"></script>
  		<script src="http://cdnjs.cloudflare.com/ajax/libs/showdown/0.3.1/showdown.min.js"></script>
  		<script src="http://cdnjs.cloudflare.com/ajax/libs/moment.js/2.1.0/moment.min.js"></script>
  		<script src="<?php echo asset_url();?>js/app.js"></script>
  		<script src="<?php echo asset_url();?>js/createVMscript.js"></script>
  		<script src="<?php echo asset_url();?>js/bootstrap.js"></script>
    
    </body>
</html>
