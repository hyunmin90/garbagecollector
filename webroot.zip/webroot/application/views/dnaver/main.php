토픽 페이지

<?php
foreach($user_model as $entry) {
?>
	<?=$entry->userid?>
<?php
}
?>
