
    <div id="footer">
      <div class="container">
        <p class="text-muted credit">Example courtesy <a href="http://martinbean.co.uk">Martin Bean</a> and <a href="http://ryanfait.com/sticky-footer/">Ryan Fait</a>.</p>
      </div>
    </div>


    <!-- Bootstrap core JavaScript-->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="http://bootstrapk.com/BS3/assets/js/jquery.js"></script>
    <script src="http://bootstrapk.com/BS3/dist/js/bootstrap.min.js"></script>
    <!-- dnaver js -->
    <script src="<?php echo asset_url();?>js/"></script>

    </body>
</html>