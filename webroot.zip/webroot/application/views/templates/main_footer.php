    <div style="width:1440px;height:52px;background-image:url('/assets_dev/footer.png');"></div>
    </body>
</html>