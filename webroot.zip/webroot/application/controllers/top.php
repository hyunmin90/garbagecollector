<?php
class Top extends CI_Controller {
	function index()
	{
		$this->load->template('dev');
	}
}
?>
