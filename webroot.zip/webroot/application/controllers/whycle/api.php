<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Example
 *
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array.
 *
 * @package		CodeIgniter
 * @subpackage	Rest Server
 * @category	Controller
 * @author		Phil Sturgeon
 * @link		http://philsturgeon.co.uk/code/
*/

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
require APPPATH.'/libraries/REST_Controller.php';

class api extends REST_Controller
{
  function __construct()
  {       
      parent::__construct();
      $this->load->model('servertocs');
  }

  function userlogin_get()//domain can not be ROOT
  {
    if(!$this->get('username')||!$this->get('password'))
    {
      $this->response(NULL, 400);
    }
      $username=$this->get('username');
      $password=$this->get('password');
      $this->response($this->servertocs->login($username,$password),200);
  }

  function vmdeploy_get()
  {
        //CPU: 500Mhz, 1Ghz, 2Ghz,  MEM: 512, 1024, 2048, STORAGE: 5GB, 10GB, 20GB, 50GB 선택적 교차 가능으로 vm policy 제작

        if(!$this->get('name')||!$this->get('templateid')||!$this->get('cpu')||!$this->get('ram')||!$this->get('hdd'))//accoount, domainid는 쿠키로
        {
          $this->response(NULL, 400);
        }

        $displayname = $this->get('name');//an optional user generated name for the virtual machine
        $templateid = $this->get('templateid');
        //$serviceofferingid = $this->get('serviceofferingid');

        $memorySize = $this->get('ram');
        $cpuSpeed = $this->get('cpu');
        $volumeSize = $this->get('hdd');        
        $diskofferingid = array('5'=> 'a83225f7-99cd-425d-8a77-82f1c6437a89','10'=> '5c332cf6-af14-47af-a6dd-3370de5fe937'
                               ,'20'=> '6222e42f-1466-4c78-8eaf-1f8fcc2f65b2','50'=> 'a8c3f6c7-1975-47a4-a76b-a9933d5928f0');

        $serviceofferingid = array(
          '500' => array('512' => '7a6d3b9c-1476-4da0-95cd-ad541d584391','1024' => 'f40d32d4-769b-4634-a4bd-0d9c0049b2be','2048' => '149cbdda-fc26-4b76-a0fc-862cf23e6340')
          ,'1' => array('512' => '63be57d6-d212-41c7-9da2-ee48d0aade8a','1024' => '5df6686e-ec28-4f1c-8250-feed590252fb','2048' => '6ae6a859-b1bd-4465-b481-75145c3d384a')
          ,'2' => array('512' => '8a64f9cb-876a-43b0-a4df-456e0be6b34d','1024' => 'acc75001-0693-4d8d-8789-32fd6a1f6c51','2048' => 'daa915af-9f6a-4935-a0e7-501a0ef58326')
        );

        /*
        $specid=$this->get('specid');//사양 e.g 작은 사양, 보통 사양
        $serviceofferingid = 1;
        //specid 에 맞는 serviceofferingid 할당
        if($specid == 'small') $serviceofferingid = '1682c1cb-e8b1-44d8-af1c-6db25a48d0e0';
        else if($specid == 'regular') $serviceofferingid = '196ed865-9f06-4307-9743-2c0a6601e85b';
        */

        $this->response($this->servertocs->vmdeploy($displayname,$templateid,$serviceofferingid[$cpuSpeed][$memorySize],$diskofferingid[$volumeSize]));
  }

  function vmstart_get()
  {
      if(!$this->get('vmid'))
        {
          $this->response(NULL, 400);
        }

        $vmid=$this->get('vmid');//The ID of the virtual machine
        $this->response($this->servertocs->vmstart($vmid));
  }

  function vmstop_get()
  {
    if(!$this->get('vmid'))
    {
      $this->response(NULL, 400);
    }

    $vmid=$this->get('vmid');//The ID of the virtual machine
    $this->response($this->servertocs->vmstop($vmid));
  }

  function vmdestroy_get()
  {
       if(!$this->get('vmid'))
        {
          $this->response(NULL, 400);
        }

        $vmid=$this->get('vmid');
        $this->response($this->servertocs->vmdestroy($vmid));
  }

    /*
  { "loginresponse" : { "timeout" : "1800", "lastname" : "cloud", "registered" : "false",
   "username" : "admin", "firstname" : "admin", "domainid" : "692094a8-0369-11e4-a62a-60a44c60711e", 
   "type" : "1", "userid" : "b97cc3c2-0369-11e4-a62a-60a44c60711e", "sessionkey" : "Rpf6myAZn565Jdb9chj8psNP0z0=", "account" : "admin" } }
    */

  function vmlist_get()
  {
      $vmid=$this->get('vmid');     
      $this->response($this->servertocs->vmlist($vmid),200);
  }

  function vmstatus_get()
  {
      if(!$this->get('jobid'))
      {
        $this->response(NULL, 400);
      }

      $jobid=$this->get('jobid');
      $this->response($this->servertocs->vmstatus($jobid));
  }

  function templateslist_get()
  {
      $this->response($this->servertocs->templateslist());
  }

  function accountinfo_get()
  {
      if(!$this->get('name'))
      {
        $this->response(NULL, 400);
      }

      $name=$this->get('name');
      $this->response($this->servertocs->accountinfo($name));
  }

  function serviceofferinglist_get()
  {
      $this->response($this->servertocs->serviceofferinglist());
  }

  function listvolumes_get()
  {
     if(!$this->get('name'))
      {
        $this->response(NULL, 400);
      }

      $name=$this->get('name');
      $this->response($this->servertocs->listvolumes($name));
  }

  function boardlist_get()
  {


  }
  function boardwrite_get()
  {


  }
  function boardmodify_get()
  {



  }
 function boarddelete_get()
 {



 }





    
}