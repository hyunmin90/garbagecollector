<?php
class main extends CI_Controller {

	function index()
	{
		$this->load->view('index');
	}
	function listvm()
	{
		$this->load->view('listvm');

	}
}
?>
