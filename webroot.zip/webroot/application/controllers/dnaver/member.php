<?php defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH.'/libraries/REST_Controller.php';

class member extends REST_Controller
{
  function __construct(){       
      parent::__construct();
      $this->openapi_db = $this->load->database('openapi',true);
      $this->load->model('dnaver/member_model'); 
  }

  function insert_get(){
    if(!$this->get('joinpath'))
      $this->response(NULL, 400);

    $joinpath=$this->get('joinpath');

    if(!strcmp($joinpath,'openapi')) $this->member_model->insert_openapi();
    else if(!strcmp($joinpath,'event')) $this->member_model->insert_event();
    else if((!strcmp($joinpath,'cafe'))) $this->member_model->insert_cafe();
    else $this->response(NULL, 400);
  }    
}