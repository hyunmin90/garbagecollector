<?php defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH.'/libraries/REST_Controller.php';

class event extends REST_Controller
{
  function __construct(){       
      parent::__construct();
      $this->load->model('test_model');
  }

  function eventinsert_get(){    
    if(!$this->get('joinpath')){
      $this->response(NULL, 400);
    }
    $joinpath=$this->get('joinpath');

    if(!strcmp($joinpath,'openapi')) $this->test_model->insert($username,$password);
    else if(!strcmp($joinpath,'event')) $this->test_model->login($username,$password);
    else if((!strcmp($joinpath,'cafe'))) $this->test_model->login($username,$password);
    else $this->response(NULL, 400);

  }    
}