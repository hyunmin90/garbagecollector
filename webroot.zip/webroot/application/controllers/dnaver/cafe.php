<?php defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH.'/libraries/REST_Controller.php';

class cafe extends REST_Controller
{
  function __construct(){       
      parent::__construct();
      $this->load->model('test_model');
  }

  function write_get(){    
    if(!$this->get('userid')||!$this->get('prize')){
      $this->response(NULL, 400);
    }
    $userid=$this->get('joinpath');
    $prize=$this->get('prize');

    if(!strcmp($joinpath,'openapi')) $this->test_model->insert($username,$password);
    else if(!strcmp($joinpath,'event')) $this->test_model->login($username,$password);
    else if((!strcmp($joinpath,'cafe'))) $this->test_model->login($username,$password);
    else $this->response(NULL, 400);

  }    
}