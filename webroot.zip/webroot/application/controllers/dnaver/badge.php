<?php defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH.'/libraries/REST_Controller.php';

//TODO call grant badge model
class badge extends REST_Controller
{
   function __construct(){       
      parent::__construct();
      $this->openapi_db = $this->load->database('openapi',true);
      $this->load->model('dnaver/badge_model'); 
  }

  function index(){
    $this->badge_model->grant_badge();
  }    
}

/* End of file badge.php */
/* Location: ./system/application/controllers/dnaver/badge.php */